# DAX Measures

```DAX
Total Urgent Samples = COUNTROWS(urgent_samples_anonymised)
Average TAT Minutes = AVERAGE(urgent_samples_anonymised[TurnaroundMinutes])
SLA Compliance % = DIVIDE(CALCULATE(COUNTROWS(urgent_samples_anonymised), urgent_samples_anonymised[WithinSLA] = "Yes"), [Total Urgent Samples])
Delayed Collections = CALCULATE(COUNTROWS(urgent_samples_anonymised), urgent_samples_anonymised[WithinSLA] = "No")
Manual Bookings = CALCULATE(COUNTROWS(urgent_samples_anonymised), urgent_samples_anonymised[CourierID] = "Manual")
```
