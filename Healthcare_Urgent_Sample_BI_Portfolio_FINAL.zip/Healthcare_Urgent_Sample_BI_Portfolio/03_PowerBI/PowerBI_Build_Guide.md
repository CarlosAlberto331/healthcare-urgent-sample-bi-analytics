# Power BI Build Guide

1. Open Power BI Desktop.
2. Get Data > Text/CSV > import `01_Data/urgent_samples_anonymised.csv`.
3. Set DateBooked and PickupDate as Date, TimeBooked and PickupTime as Time, TurnaroundMinutes and SLAMinutes as Whole Number.
4. Create the DAX measures from `DAX_Measures.md`.
5. Build one report page named Executive Operations Dashboard.
6. Add KPI cards: Total Urgent Samples, Average TAT Minutes, SLA Compliance %, Delayed Collections, Manual Bookings.
7. Add visuals: samples by date, courier performance, status breakdown, sample type volume, exception table.
