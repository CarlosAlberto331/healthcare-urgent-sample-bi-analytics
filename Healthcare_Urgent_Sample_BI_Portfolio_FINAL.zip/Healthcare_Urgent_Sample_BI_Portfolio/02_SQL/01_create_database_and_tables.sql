CREATE DATABASE UrgentSampleBI;
GO
USE UrgentSampleBI;
GO

CREATE TABLE dbo.FactUrgentSamples (
    RecordID INT PRIMARY KEY,
    DateBooked DATE NOT NULL,
    TimeBooked TIME NOT NULL,
    CourierBookingReference VARCHAR(50),
    PickupDate DATE NOT NULL,
    PickupTime TIME NOT NULL,
    CourierID VARCHAR(50),
    SampleType VARCHAR(100),
    Origin VARCHAR(100),
    Destination VARCHAR(100),
    Status VARCHAR(50),
    TurnaroundMinutes INT,
    SLAMinutes INT,
    WithinSLA VARCHAR(3),
    Comments VARCHAR(255)
);
