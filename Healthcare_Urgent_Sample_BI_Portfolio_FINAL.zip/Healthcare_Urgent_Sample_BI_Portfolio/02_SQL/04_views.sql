CREATE VIEW dbo.vw_UrgentSampleKPI AS
SELECT
 COUNT(*) AS TotalSamples,
 AVG(TurnaroundMinutes) AS AvgTAT,
 SUM(CASE WHEN WithinSLA='Yes' THEN 1 ELSE 0 END) AS WithinSLA,
 SUM(CASE WHEN WithinSLA='No' THEN 1 ELSE 0 END) AS BreachedSLA
FROM dbo.FactUrgentSamples;
GO
