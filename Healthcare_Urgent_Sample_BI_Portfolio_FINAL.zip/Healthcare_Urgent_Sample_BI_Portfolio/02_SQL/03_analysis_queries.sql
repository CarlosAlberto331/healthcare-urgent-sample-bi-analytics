-- KPI Queries
SELECT COUNT(*) AS TotalUrgentSamples FROM dbo.FactUrgentSamples;

SELECT AVG(TurnaroundMinutes) AS AverageTurnaroundMinutes FROM dbo.FactUrgentSamples;

SELECT WithinSLA, COUNT(*) AS SampleCount FROM dbo.FactUrgentSamples GROUP BY WithinSLA;

SELECT CourierID, COUNT(*) AS TotalCollections, AVG(TurnaroundMinutes) AS AvgTAT
FROM dbo.FactUrgentSamples GROUP BY CourierID ORDER BY AvgTAT;

SELECT DateBooked, COUNT(*) AS DailyVolume
FROM dbo.FactUrgentSamples GROUP BY DateBooked ORDER BY DateBooked;

SELECT Status, COUNT(*) AS Total
FROM dbo.FactUrgentSamples GROUP BY Status ORDER BY Total DESC;

SELECT SampleType, COUNT(*) AS Total, AVG(TurnaroundMinutes) AS AvgTAT
FROM dbo.FactUrgentSamples GROUP BY SampleType ORDER BY Total DESC;

SELECT TOP 10 * FROM dbo.FactUrgentSamples WHERE WithinSLA='No' ORDER BY TurnaroundMinutes DESC;
