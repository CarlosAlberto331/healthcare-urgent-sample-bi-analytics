# Healthcare Urgent Sample BI Analytics

End-to-end healthcare Business Intelligence portfolio project analysing urgent laboratory sample workflows using SQL, Excel and Power BI-ready modelling.

## Business Problem
Urgent laboratory samples are time-critical. Manual logbooks make it difficult to monitor turnaround time, identify courier delays and report service performance.

## Project Objectives
- Convert urgent sample tracking into structured data.
- Define KPIs for turnaround time, SLA compliance and courier performance.
- Create SQL scripts for analysis and reporting.
- Provide Power BI-ready measures and dashboard specification.

## Repository Structure
- `01_Data` - anonymised dataset and data quality notes
- `02_SQL` - database schema, inserts, views and analysis queries
- `03_PowerBI` - DAX measures and build guide
- `04_Documentation` - business case, KPI definitions and technical notes
- `05_Images` - diagrams and dashboard mockups

## Key KPIs
- Total urgent samples
- Average turnaround time
- SLA compliance percentage
- Delayed collections
- Manual bookings
- Courier performance

## Tools
SQL Server, Microsoft Excel, Power BI, DAX, data modelling, healthcare analytics.

## Note
This is an anonymised portfolio project based on the structure of a scanned urgent sample tracking log. It contains no patient identifiers.
