# Data Quality Report

This portfolio uses anonymised demonstration records derived from the structure of the scanned urgent sample log. No patient identifiers are included. Handwritten source material should be manually verified before operational use.

Checks included: date/time fields, SLA flag, missing comment review, courier categorisation and turnaround calculation.
