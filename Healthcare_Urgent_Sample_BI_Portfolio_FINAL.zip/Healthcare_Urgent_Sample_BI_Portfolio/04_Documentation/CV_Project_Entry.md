Healthcare BI Analytics Project - Urgent Sample Tracking
- Built an anonymised BI reporting solution for urgent laboratory sample tracking using SQL, Excel and Power BI-ready modelling.
- Designed KPIs for turnaround time, courier performance, delayed collections and operational exceptions.
- Produced SQL scripts, dashboard specifications and documentation suitable for healthcare performance reporting.
