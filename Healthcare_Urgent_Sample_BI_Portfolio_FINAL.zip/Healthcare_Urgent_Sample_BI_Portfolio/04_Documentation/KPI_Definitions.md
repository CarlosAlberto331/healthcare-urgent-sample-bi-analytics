# KPI Definitions

| KPI | Definition | Purpose |
|---|---|---|
| Total Urgent Samples | Count of urgent sample records | Workload monitoring |
| Average TAT | Average minutes from booking to pickup | Operational efficiency |
| SLA Compliance % | % collected within SLA minutes | Service performance |
| Delayed Collections | Count outside SLA | Exception management |
| Manual Bookings | Count where courier was manually booked | Process friction indicator |
